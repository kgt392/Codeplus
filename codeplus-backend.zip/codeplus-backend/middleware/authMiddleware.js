export const authMiddleware = (req, res, next) => {
  // For now, simple placeholder since we don't have JWT
  const userId = req.headers["x-user-id"];
  if (!userId) return res.status(401).json({ msg: "Unauthorized" });
  req.userId = userId;
  next();
};
