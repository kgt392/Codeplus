import User from "../models/User.js";

import User from "../models/User.js";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";

export const signup = async (req, res) => {
  try {
    const { email, password } = req.body;
    const existingUser = await User.findOne({ email });
    if (existingUser) return res.status(400).json({ msg: "User already exists" });

    const hashedPassword = await bcrypt.hash(password, 10);
    const user = await User.create({ email, password: hashedPassword });

    // send back user info + token
    const token = jwt.sign({ id: user._id }, "secretkey", { expiresIn: "1d" });
    res.status(201).json({ user: { _id: user._id, email: user.email }, token });
  } catch (err) {
    res.status(500).json({ msg: err.message });
  }
};


export const login = async (req, res) => {
  const { email, password } = req.body;
  try {
    const user = await User.findOne({ email, password });
    if (!user) return res.status(400).json({ msg: "Invalid credentials" });
    res.json({ msg: "Login successful", user });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};
