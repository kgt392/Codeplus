import Solution from "../models/Solution.js";
import Problem from "../models/Problem.js";

export const getProgress = async (req, res) => {
  try {
    const userId = req.userId;
    const total = await Problem.countDocuments();
    const solved = await Solution.countDocuments({ userId, correct: true });
    res.json({ total, solved, progress: solved / total });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};
