// import express from "express";
// const router = express.Router();

// // Mock problems (no MongoDB)
// const problems = [
//   { title: "Two Sum", description: "Find two numbers that add to target" },
//   { title: "Reverse String", description: "Reverse a given string" },
//   { title: "Palindrome Check", description: "Check if a string is palindrome" }
// ];

// router.get("/", (req, res) => {
//   res.json(problems);
// });

// export default router;

import express from "express";
import { getProblems } from "../controllers/problemController.js";

const router = express.Router();

router.get("/", getProblems);

export default router;
