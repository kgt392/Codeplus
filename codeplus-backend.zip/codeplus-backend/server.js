// // server.js
// import express from "express";
// import http from "http";
// import { Server } from "socket.io";
// import cors from "cors";
// import path from "path"; 

// const app = express();
// app.use(cors());
// app.use(express.json());

// const __dirname = path.resolve();
// app.use(express.static(path.join(__dirname, "public")));

// app.use(express.static(path.join(__dirname, "public")));

// // Safe catch-all for frontend routing
// app.get("*.*", (req, res, next) => next());

// app.get("*", (req, res) => {
//   res.sendFile(path.join(__dirname, "public", "index.html"));
// });

// const server = http.createServer(app);
// const io = new Server(server, {
//   cors: {
//     origin: "*",
//   },
// });

// const PORT = 5000;

// // A sample problem (you can later load from MongoDB)
// const problems = [
//   {
//     id: 1,
//     title: "Fibonacci Sequence",
//     description:
//       "Write a function to return the nth Fibonacci number. Example: fib(5) → 5",
//     input: "5",
//     expectedOutput: "5",
//   },
// ];

// // In-memory room data
// let rooms = {};

// app.get("/", (req, res) => {
//   res.send("Coding Battle Backend Running ✅");
// });

// app.get("/problems", (req, res) => {
//   res.json(problems);
// });

// // --- Socket Logic ---
// io.on("connection", (socket) => {
//   console.log("🟢 A user connected:", socket.id);

//   // Player creates or joins a room
//   socket.on("joinRoom", (roomId) => {
//     if (!rooms[roomId]) {
//       rooms[roomId] = { players: [] };
//     }

//     const room = rooms[roomId];
//     if (room.players.length < 2) {
//       room.players.push(socket.id);
//       socket.join(roomId);
//       console.log(`User ${socket.id} joined room ${roomId}`);

//       if (room.players.length === 2) {
//         io.to(roomId).emit("startGame", problems[0]); // Send problem to both
//       }
//     } else {
//       socket.emit("roomFull");
//     }
//   });

//   socket.on("submitSolution", ({ roomId, output }) => {
//     const correct = output.trim() === problems[0].expectedOutput;
//     io.to(roomId).emit("solutionResult", {
//       player: socket.id,
//       correct,
//     });
//   });

//   socket.on("disconnect", () => {
//     console.log("🔴 User disconnected:", socket.id);
//     for (let [roomId, room] of Object.entries(rooms)) {
//       room.players = room.players.filter((id) => id !== socket.id);
//       if (room.players.length === 0) delete rooms[roomId];
//     }
//   });
// });

// server.listen(PORT, () =>
//   console.log(`🚀 Server running on http://localhost:${PORT}`)
// );

// server.js
// import express from "express";
// import http from "http";
// import { Server } from "socket.io";
// import cors from "cors";
// import path from "path";

// const app = express();
// app.use(cors());
// app.use(express.json());

// const PORT = 5000;
// const __dirname = path.resolve();

// // --- Serve frontend build ---
// app.use(express.static(path.join(__dirname, "public")));

// // Catch-all to serve index.html for frontend routing
// app.get("/", (req, res) => {
//   res.sendFile(path.join(__dirname, "public", "index.html"));
// });

// // --- Backend API ---
// const problems = [
//   {
//     id: 1,
//     title: "Fibonacci Sequence",
//     description: "Write a function to return the nth Fibonacci number. Example: fib(5) → 5",
//     input: "5",
//     expectedOutput: "5",
//   },
// ];

// let rooms = {};

// app.get("/problems", (req, res) => {
//   res.json(problems);
// });

// // --- Socket.IO setup ---
// const server = http.createServer(app);
// const io = new Server(server, {
//   cors: {
//     origin: "*",
//   },
// });

// io.on("connection", (socket) => {
//   console.log("🟢 A user connected:", socket.id);

//   socket.on("joinRoom", (roomId) => {
//     if (!rooms[roomId]) rooms[roomId] = { players: [] };
//     const room = rooms[roomId];

//     if (room.players.length < 2) {
//       room.players.push(socket.id);
//       socket.join(roomId);
//       console.log(`User ${socket.id} joined room ${roomId}`);

//       if (room.players.length === 2) {
//         io.to(roomId).emit("startGame", problems[0]);
//       }
//     } else {
//       socket.emit("roomFull");
//     }
//   });

//   socket.on("submitSolution", ({ roomId, output }) => {
//     const correct = output.trim() === problems[0].expectedOutput;
//     io.to(roomId).emit("solutionResult", {
//       player: socket.id,
//       correct,
//     });
//   });

//   socket.on("disconnect", () => {
//     console.log("🔴 User disconnected:", socket.id);
//     for (let [roomId, room] of Object.entries(rooms)) {
//       room.players = room.players.filter((id) => id !== socket.id);
//       if (room.players.length === 0) delete rooms[roomId];
//     }
//   });
// });

// // --- Start server ---
// server.listen(PORT, () => {
//   console.log(`🚀 Server running on http://localhost:${PORT}`);
//   console.log("Coding Battle Backend Running ✅");
// });


// server.js
// server.js
import express from "express";
import http from "http";
import { Server } from "socket.io";
import cors from "cors";
import path from "path";
import connectDB from "./config/db.js";
import authRoutes from "./routes/authRoutes.js";
import problemRoutes from "./routes/problemRoutes.js";
import Solution from "./models/Solution.js";
import Problem from "./models/Problem.js";
import { fileURLToPath } from "url";
import { dirname, join } from "path";

// Connect to MongoDB
connectDB();

const app = express();
const PORT = 5000;
const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

// Middleware
app.use(cors());
app.use(express.json());

// --- API Routes ---
app.use("/api/auth", authRoutes);
app.use("/api/problems", problemRoutes);

// --- Serve frontend (Vite build in public) ---
app.use(express.static(join(__dirname, "public")));

// Catch-all route for React/Vite frontend
app.get(/.*/, (req, res) => {
  res.sendFile(join(__dirname, "public", "index.html"));
});
// --- Socket.IO for 1v1 ---
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: "*" } });

let rooms = {}; // in-memory room tracking

io.on("connection", (socket) => {
  console.log("🟢 User connected:", socket.id);

  // Join or create room
  socket.on("joinRoom", (roomId) => {
    if (!rooms[roomId]) rooms[roomId] = { players: [] };
    const room = rooms[roomId];

    if (room.players.length < 2) {
      room.players.push(socket.id);
      socket.join(roomId);
      console.log(`User ${socket.id} joined room ${roomId}`);

      // Start game when 2 players present
      if (room.players.length === 2) {
        Problem.findOne({}).then((problem) => {
          io.to(roomId).emit("startGame", problem);
        });
      }
    } else {
      socket.emit("roomFull");
    }
  });

  // Receive solution from client
  socket.on("submitSolution", async ({ roomId, code, language, userId }) => {
    try {
      const problem = await Problem.findOne({});
      const output = code.includes("5") ? "5" : "0"; // Mock code execution
      const correct = output === problem.expectedOutput;

      // Save solution in DB
      await Solution.create({
        userId,
        problemId: problem._id,
        code,
        language,
        output,
        correct,
      });

      // Broadcast result to room
      io.to(roomId).emit("solutionResult", { player: socket.id, correct });
    } catch (err) {
      console.error(err);
    }
  });

  // Handle disconnect
  socket.on("disconnect", () => {
    console.log("🔴 User disconnected:", socket.id);
    for (let roomId in rooms) {
      rooms[roomId].players = rooms[roomId].players.filter((id) => id !== socket.id);
      if (rooms[roomId].players.length === 0) delete rooms[roomId];
    }
  });
});

// Start server
server.listen(PORT, () => {
  console.log(`🚀 Server running on http://localhost:${PORT}`);
});
