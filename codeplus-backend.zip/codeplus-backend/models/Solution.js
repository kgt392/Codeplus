import mongoose from "mongoose";

const SolutionSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
  problemId: { type: mongoose.Schema.Types.ObjectId, ref: "Problem" },
  language: String,
  code: String,
  output: String,
  correct: Boolean,
  submittedAt: { type: Date, default: Date.now },
});

export default mongoose.model("Solution", SolutionSchema);
