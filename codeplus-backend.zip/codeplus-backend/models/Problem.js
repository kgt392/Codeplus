import mongoose from "mongoose";

const ProblemSchema = new mongoose.Schema({
  title: String,
  description: String,
  input: String,
  expectedOutput: String,
});

export default mongoose.model("Problem", ProblemSchema);
