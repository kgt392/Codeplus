import mongoose from "mongoose";

const connectDB = async () => {
  try {
    await mongoose.connect("mongodb://127.0.0.1:27017/codeplus", {
      useNewUrlParser: true,
      useUnifiedTopology: true,
    });
    console.log("MongoDB connected ✅");
  } catch (err) {
    console.error(err);
    process.exit(1);
  }
};

export default connectDB;

// 33ek2gO9vULZ2pf2Won1CurH5GW_6hJV6EHHg28qw7gzzggzG
  // https://petronila-shuttlelike-unsolidly.ngrok-free.dev // temporary ngrok for demo